from django.contrib import admin
from.models import Post,Notice,Event,Workpost
 
# Register your models here.

admin.site.site_header='Admin'


admin.site.register(Post)
admin.site.register(Notice)
admin.site.register(Event)
admin.site.register(Workpost)

