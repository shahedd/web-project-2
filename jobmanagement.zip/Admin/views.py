from django.shortcuts import render, redirect
 

def registration(request):
     
        return render(request, 'adminregister.html')


def adminlogin(request):
 
        return render(request,'adminlogin.html')










def adminpage(request):
    return render(request, "adminpage.html")
