 
from django.urls import path
from . import views

urlpatterns = [
        path('adminpage',views.adminpage, name='adminpage'),
        path('adminregister',views.registration, name='registration'),
        path('login',views.adminlogin, name='login')


        
]