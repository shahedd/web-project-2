
from django.db import models


# Create your models here.
class Post(models.Model):
    title = models.CharField(max_length=60, blank=False)
    description = models.TextField( blank=False)

    added = models.DateField(auto_now_add=True)


class Notice(models.Model):
    title = models.CharField(max_length=100, blank=False)
    description = models.TextField(blank=False)
    added = models.DateField(auto_now_add=True)


class Event(models.Model):
    title = models.CharField(max_length=60, blank=False)
    description = models.CharField(max_length=400, blank=False)
    photo_url = models.ImageField(blank=True)
    event_held = models.TextField(blank=False)
    added = models.DateField(auto_now_add=True)


class Workpost(models.Model):
    title = models.CharField(max_length=60, blank=False)
    description = models.TextField(blank=False)
    added = models.DateField(auto_now_add=True)
