from django.urls import path
from . import views

urlpatterns = [
        path('userpage',views.userpage, name='userpage'),
        path('noticepage', views.noticepage, name='noticepage'),
        path('eventpage', views.eventpage, name='eventpage'),
        path('grouppage', views.grouppage, name='grouppage'),
        path('registration',views.userreg, name='registration'),
        path('login',views.userlogin, name='login'),
        path('logout',views.userlogout, name='logout')


]


