from django.shortcuts import render,redirect,get_object_or_404
from django.contrib.auth.models import User,auth
from Admin.models import Post,Notice,Event,Workpost
from jobmanagement import settings
from django.contrib import messages

def userreg(request):
          
          if request.method == 'POST':
               
               name = request.POST['name']
               firstname = request.POST['firstname']
               lastname = request.POST['lastname']
               email = request.POST['email']
               password = request.POST['password']

               if User.objects.filter(username=name).exists():
                   messages.info(request, 'Username Taken')
                   return  render(request,'userregister.html')
               else:
                   user= User.objects.create_user(username=name,first_name=firstname,last_name=lastname,password=password,
               email=email)
               user.save()
               return  render(request,'userlogin.html')
          else:
               return  render(request,'userregister.html')
              
          
def userlogin(request):

               if request.method == 'POST':
                    
                     name = request.POST['name']
                     password = request.POST['password']
                    
                         
                     user = auth.authenticate(username=name,password=password)
                    
                     if user is not None:
                        
                         auth.login(request, user)
                         
                         return redirect("userpage")
                     
                     else:
                             
                         return redirect("registration")
                    
               else:

                     return render(request,"userlogin.html")

     
          
def userpage(request):
    admindata =Post.objects.all().order_by('-id')

    return render(request, "userpage.html", {'admindatas': admindata})


def noticepage(request):
    admindata = Notice.objects.all().order_by('-id')

    return render(request, "noticepage.html", {'admindatas': admindata})


def eventpage(request):
    admindata= Event.objects.all().order_by('-id')

    return render(request, "eventpage.html", {'admindatas': admindata})

def grouppage(request):

    admindata = Workpost.objects.all().order_by('-id')


    return render(request, "grouppage.html", {'admindatas': admindata})




def userlogout(request):

               auth.logout(request)
               return redirect('/')

