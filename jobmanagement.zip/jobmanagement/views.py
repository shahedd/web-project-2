from django.shortcuts import render,redirect
from django.contrib.auth.models import User,auth
from django.contrib import messages

def home(request):
     if request.method == 'POST':
               
               
               email = request.POST['email']
               password = request.POST['password']
               
               
               user= auth.authenticate(email=email,password=password)
               
               if user is not None:
                    auth.login(request,user)
                    return  render(request,'userpage.html')
               else:
                    messages.info(request,'invalid information')

     else:
          return  render(request,'home.html')